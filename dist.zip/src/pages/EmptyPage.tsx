import React from "react";

const EmptyPage: React.FC = () => {
    return <h2>This is an empty page</h2>;
};

export default EmptyPage;
