import React from "react";
import Jobs from "./Jobs";

const Dashboard: React.FC = () => {
    return <Jobs/>;
};

export default Dashboard;
