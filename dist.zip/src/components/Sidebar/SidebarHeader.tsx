import { Box, IconButton } from "@mui/material";
import SaveIcon from "@mui/icons-material/Check";
import CancelIcon from "@mui/icons-material/Close";
import styles from "./Sidebar.module.scss";
import SettingsIcon from "../../assets/images/icons/setting.png";

interface SidebarHeaderProps {
    editMode: boolean;
    toggleEditMode: () => void;
    saveChanges: () => void;
}

const SidebarHeader: React.FC<SidebarHeaderProps> = ({ editMode, toggleEditMode, saveChanges }) => {
    return (
        <Box className={styles.menuHeader}>
            <span>Menu</span>
            <Box className={styles.editIcons}>
                {editMode ? (
                    <>
                        <IconButton onClick={saveChanges} className={styles.actionButton} sx={{ border: "2px solid green", color: "green" }}>
                            <SaveIcon  fontSize="medium" />
                        </IconButton>
                        <IconButton onClick={toggleEditMode} className={styles.actionButton} sx={{ border: "2px solid red", color: "red" }}>
                            <CancelIcon fontSize="medium" />
                        </IconButton>
                    </>
                ) : (
                    <IconButton onClick={toggleEditMode}>
                        <img src={SettingsIcon} width="24px" height="24px" />
                    </IconButton>
                )}
            </Box>
        </Box>
    );
};

export default SidebarHeader;
